# Logomachia

Gioco di carte a tema filosofico (pixel art). Apri i pacchetti, raccogli i filosofi e sfidali in dibattiti a turni, contro il computer o in due sullo stesso schermo.

Progetto di filosofia (Opzione A: rielaborazione personale degli autori e delle correnti).

## Come giocare

- **Online:** https://TUO-NOME-UTENTE.github.io/logomachia/ (vedi sotto come attivarlo)
- **In locale:** scarica la cartella e fai doppio clic su `index.html`. Funziona anche senza internet.

I progressi (collezione, pacchetti, volume) sono salvati nel browser, quindi ognuno ha la propria collezione.

## Pubblicare su GitHub Pages

1. Crea un repository su GitHub (es. `logomachia`) e carica tutti i file di questa cartella.
2. Vai in **Settings → Pages**.
3. In *Build and deployment* scegli **Deploy from a branch**, branch `main`, cartella `/ (root)`, poi **Save**.
4. Dopo un minuto circa il gioco è online all'indirizzo `https://<tuo-utente>.github.io/<nome-repo>/`.

## File

| File | Cosa contiene |
| --- | --- |
| `index.html` | Il gioco (HTML, CSS e JavaScript in un solo file) |
| `filosofi.json` | Il database: filosofi, attacchi, frasi, debolezze, temi |

Per aggiungere o modificare un filosofo si modifica `filosofi.json`. Attenzione: `index.html` contiene anche una copia di riserva del database (il blocco `db-fallback`), usata quando la pagina viene aperta con doppio clic. Se modifichi `filosofi.json`, aggiorna anche quel blocco, oppure usa la versione online, che legge sempre `filosofi.json`.

## Note

- La musica è generata dal browser e parte dopo il primo clic. Il volume si regola in **Impostazioni**.
- Font: Pixelify Sans e Press Start 2P (Google Fonts). Senza internet si usa un carattere di riserva.
